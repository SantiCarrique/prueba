/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Modelo;
import model.ModeloDao;
import view.Pantalla;

public class ModeloControlador implements ActionListener, MouseListener, KeyListener {
    private Modelo modelo;
    private ModeloDao modeloDao;
    private Pantalla panta;

    DefaultTableModel model = new DefaultTableModel();

    public ModeloControlador(Modelo modelo, ModeloDao modeloDao, Pantalla panta) {
        this.modelo = modelo;
        this.modeloDao = modeloDao;
        this.panta = panta;
        
        //Botón de registrar autor
        this.panta.btn_Agregar_Modelo.addActionListener(this);
        //Botón de modificar autor
        this.panta.btn_Modificar_Modelo.addActionListener(this);
        //Botón de borrar autor
        this.panta.btn_Borrar_Modelo.addActionListener(this);
        //Botón de limpiar
        this.panta.btn_Limpiar_Modelo.addActionListener(this);
        
        //Listado de autor
        this.panta.tb_Modelo.addMouseListener(this);
              
        listarModelos(); 
        
    }

    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == panta.btn_Agregar_Modelo){
            //verifica si el campo nombre está vacío
            if(panta.txt_Modelo.getText().equals("")){
                JOptionPane.showMessageDialog(null, "El campo modelo es obligatorio");
            }else{
                //Realiza el agregado
                modelo.setModelo(panta.txt_Modelo.getText());
                if(modeloDao.agregarModelo(modelo)){
                    limpiarTabla();
                    limpiarCampos();
                    listarModelos();
                    JOptionPane.showMessageDialog(null, "Se agregó el modelo");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al agregar el modelo");
                }
            }
        }else if(e.getSource() == panta.btn_Modificar_Modelo){
            //verifica si el campo id está vacío
            if(panta.txt_Id_Modelo.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Debe seleccionar un registro desde la tabla");
            }else{
                //Realiza la modificación
                modelo.setIdModelo(Integer.parseInt(panta.txt_Id_Modelo.getText()));
                modelo.setModelo(panta.txt_Modelo.getText());
                if(modeloDao.modificarModelo(modelo)){
                    limpiarTabla();
                    limpiarCampos();
                    listarModelos();
                    JOptionPane.showMessageDialog(null, "Se modificó el modelo");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al modificar el modelo");
                }
            }
        }else if(e.getSource() == panta.btn_Borrar_Modelo){
            //verifica si el campo id está vacío
            if(panta.txt_Id_Modelo.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Debe seleccionar un registro desde la tabla");
            }else{
                //Realiza el borrado
                int id = Integer.parseInt(panta.txt_Id_Modelo.getText());
                if(modeloDao.borrarModelo(id)){
                    limpiarTabla();
                    limpiarCampos();
                    listarModelos();
                    JOptionPane.showMessageDialog(null, "Se eliminó el modelo");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al eliminar el modelo");
                }
            }
        }else if(e.getSource() == panta.btn_Limpiar_Modelo){
                limpiarTabla();
                limpiarCampos();
                listarModelos();    
                panta.btn_Agregar_Modelo.setEnabled(true);
        }    
    }

    @Override
    public void mouseClicked(MouseEvent e) {
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        if(e.getSource() == panta.tb_Modelo){
            int row = panta.tb_Modelo.rowAtPoint(e.getPoint());
            panta.txt_Id_Modelo.setText(panta.tb_Modelo.getValueAt(row,0).toString());
            panta.txt_Modelo.setText(panta.tb_Modelo.getValueAt(row,1).toString());
            //Deshabilitar
            panta.btn_Agregar_Modelo.setEnabled(false);
        }
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
    }

    @Override
    public void keyReleased(KeyEvent e) {
    }

    //Listar todos los autores
    public void listarModelos(){

        panta.cmb_Modelo.removeAllItems();

        List<Modelo> list = modeloDao.listarModelo();
        model = (DefaultTableModel) panta.tb_Modelo.getModel();
        Object[] row = new Object[2];
        limpiarTabla();
        for(int i = 0; i < list.size(); i++){
            row[0] = list.get(i).getIdModelo();
            row[1] = list.get(i).getModelo();
            model.addRow(row);
            panta.cmb_Modelo.addItem(list.get(i).getModelo());
        }
    }


    //Limpiar la tabla
    public void limpiarTabla(){
        for (int i = 0; i < model.getRowCount(); i++){
            model.removeRow(i);
            i = i - 1;
        }
    }
    //Limpiar los campos
    public void limpiarCampos(){
        panta.txt_Id_Modelo.setText("");
        panta.txt_Modelo.setText("");
    }
    
}

   

