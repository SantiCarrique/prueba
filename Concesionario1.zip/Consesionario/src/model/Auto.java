/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;


import java.sql.CallableStatement;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.sql.Statement;
import java.sql.ResultSet;


public class Auto {
    int idauto;
    int idmarca;
    int idmodelo;
    int idversion;
    int anio;
    Double precio;
    int kilometros;
    String combustible;
    int puertas;
    String condicion;
    String NombreAuto;
    public Auto() {
    }

    public Auto(int idauto, int idmarca, int idmodelo, int idversion, int anio, Double precio, int kilometros, String combustible, int puertas, String condicion) {
        this.idauto = idauto;
        this.idmarca = idmarca;
        this.idmodelo = idmodelo;
        this.idversion = idversion;
        this.anio = anio;
        this.precio = precio;
        this.kilometros = kilometros;
        this.combustible = combustible;
        this.puertas = puertas;
        this.condicion = condicion;
    }

    public int getIdauto() {
        return idauto;
    }

    public void setIdauto(int idauto) {
        this.idauto = idauto;
    }

    public int getIdmarca() {
        return idmarca;
    }

    public void setIdmarca(int idmarca) {
        this.idmarca = idmarca;
    }

    public int getIdmodelo() {
        return idmodelo;
    }

    public void setIdmodelo(int idmodelo) {
        this.idmodelo = idmodelo;
    }

    public int getIdversion() {
        return idversion;
    }

    public void setIdversion(int idversion) {
        this.idversion = idversion;
    }

    public int getAnio() {
        return anio;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }

    public Double getPrecio() {
        return precio;
    }

    public void setPrecio(Double precio) {
        this.precio = precio;
    }

    public int getKilometros() {
        return kilometros;
    }

    public void setKilometros(int kilometros) {
        this.kilometros = kilometros;
    }

    public String getCombustible() {
        return combustible;
    }

    public void setCombustible(String combustible) {
        this.combustible = combustible;
    }

    public int getPuertas() {
        return puertas;
    }

    public void setPuertas(int puertas) {
        this.puertas = puertas;
    }

    public String getCondicion() {
        return condicion;
    }

    public void setCondicion(String condicion) {
        this.condicion = condicion;
    }
 public String getNombreAuto() {
        return NombreAuto;
    }

    public void setNombreAuto(String nombreAutor) {
        this.NombreAuto = nombreAutor;
    }
}
    