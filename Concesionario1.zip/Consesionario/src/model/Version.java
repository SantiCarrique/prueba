package model;


import java.sql.CallableStatement;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.sql.Statement;
import java.sql.ResultSet;


public class Version {
   
    int idversion;
    String NombreVersion;
    public Version() {
    }

    public Version(int idversion) {
        this.idversion = idversion;
    }

    public int getIdversion() {
        return idversion;
    }

    public void setIdversion(int idversion) {
        this.idversion = idversion;
    }

    public String getNombreVersion() {
        return NombreVersion;
    }

    public void setNombreVersion(String NombreVersion) {
        this.NombreVersion = NombreVersion;
    }


}